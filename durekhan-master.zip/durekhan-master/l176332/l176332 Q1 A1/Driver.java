/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Dure Khan
 */
public class Driver extends User {
    private
    final String email;
    String Password;
    int pay;
    String feedback;
    public
            Driver()
            {
                email=null;
                Password=null;
                pay=0;
                feedback=null;
            }
            Driver(String name,String ph,String location,String e,String password,int pay1)
            {
                super(name,ph,location);
                email=e;
                Password=password;
                pay=pay1;
                feedback=null;
            }
           
}
