/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Dure Khan
 */
public class Customer extends User{
    private
    final String email;
    String Password;
    String DropOff_Location;
    int bill;
    public
            Customer()
            {
                email=null;
                Password=null;
                DropOff_Location=null;
                bill=0;
            }
            Customer(String n,String p,String l,String dl,String e,String P)
            {
                super(n,p,l);
                email=e;
                Password=P;
                DropOff_Location=dl;
                bill=0;
            }
            public String Get_Drop_Off_Location()
            {
                return DropOff_Location;
            }
            Driver Find_Driver(List<Driver> drivers)
            {
                Driver d=new Driver();
                long total = drivers.stream().count();
                boolean flag=false;
                for(int i=0;i<total&&flag==false;i++)
                {
                    if(Starting_Location.compareTo(drivers.get(i).Starting_Location)==0)
                    {
                       d=drivers.get(i);
                    }
                }
                return d;
            }
            boolean Find_Cab(List<Driver> drivers)
            {
                
                long total = drivers.stream().count();
                boolean flag=false;
                for(int i=0;i<total&&flag==false;i++)
                {
                    if(Starting_Location.compareTo(drivers.get(i).Starting_Location)==0)
                    {
                        flag=true;
                        return flag;
                    }
                }
                return flag;
            }
            void Leave_Feedback(Driver d)
            {
             System.out.println("Please Leave your feedback for the Driver");
           
             Scanner userInput = new Scanner(System.in);
             
             d.feedback=userInput.nextLine();
            }
}
