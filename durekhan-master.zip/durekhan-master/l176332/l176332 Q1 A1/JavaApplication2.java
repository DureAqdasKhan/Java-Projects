/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Dure Khan
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
       Driver d=new Driver();
       List<Driver> drivers=new ArrayList<Driver>();
       Driver d1=new Driver("Ali","0332-123","Model Town","ali10@gmail.com","Ali10",5000);
       Driver d2=new Driver("Ahmed","0331-134","Iqbal Town","ahmed01@gmail.com","A10",5000);
       Driver d3=new Driver("Ahmar","0334-133324","Bahria Town","ahmar01@gmail.com","Ah0",3000);
       drivers.add(d1);
       drivers.add(d2);
       drivers.add(d3);
       Customer c1=new Customer("Dure","033-232232","Bahria Town","Model Town","dure10@gmail.com","d10");
       
       if(c1.Find_Cab(drivers))
       {
           
           d=c1.Find_Driver(drivers);
           System.out.println("Ride Found. Captain "+d.name +" is on his way to pickup you up");
           
           c1.Calculate_Invoice(c1);
           
           System.out.println("Your total bill is Rs: "+ c1.bill);
           
           
           c1.Leave_Feedback(d);
           
           System.out.println("Thankyou for travelling with us!");
       }
       else
       {
           System.out.println("No Ride Found Nearby");
       }
    }   
}
