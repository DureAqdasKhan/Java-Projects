/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Dure Khan
 */
public abstract class User {
    public
    String name;
    String Phone_No;
    float rating;
    String Starting_Location;
    String [] locations=new String[3];
    User()
    {
        name=null;
        Phone_No=null;
        rating=0;
        Starting_Location=null;
        locations[0]="Model Town";
        locations[1]="Bahria Town";
        locations[2]="Iqbal Town";
    }
    User(String name1,String ph,String loc )
    {
        name=name1;
        Phone_No=ph;
        rating=0;
        Starting_Location=loc;
    }
    public void Calculate_Invoice(Customer c)
    {
        int bill;
        if(Starting_Location.compareTo("Model Town")==0&&c.Get_Drop_Off_Location().compareTo("Iqbal Town")==0)
        {
            bill=300;
            c.bill=bill;
        }
        else if(Starting_Location.compareTo("Iqbal Town")==0&&c.Get_Drop_Off_Location().compareTo("Model Town")==0)
        {
            bill=300;
            c.bill=bill;
        }
        else if(Starting_Location.compareTo("Model Town")==0&&c.Get_Drop_Off_Location().compareTo("Bahria Town")==0)
        {
            bill=800;
            c.bill=bill;
        }
        else if(Starting_Location.compareTo("Bahria Town")==0&&c.Get_Drop_Off_Location().compareTo("Model Town")==0)
        {
            bill=800;
            c.bill=bill;
        }
        else if(Starting_Location.compareTo("Iqbal Town")==0&&c.Get_Drop_Off_Location().compareTo("Bahria Town")==0)
        {
          bill=1000;  
          c.bill=bill;
        }
        else
        {
            bill=1000;
            c.bill=bill;
        }
    }
}
