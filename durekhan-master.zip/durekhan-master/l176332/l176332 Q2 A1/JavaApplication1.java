/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.List;
import java.time.*;
import java.util.ArrayList;

/**
 *
 * @author Dure Khan
 */


public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void Winner(List<Candidate> candidates)
    {
         long total = candidates.stream().count(); 
         int max=0;
         Candidate c= new Candidate();
         for(int i=0;i<total;i++)
         {
            if( candidates.get(i).vote_count>max)
            {
                max=candidates.get(i).vote_count;
                c=candidates.get(i);
            }
            
         }
         System.out.println("Winner is: "+ c.name + " of Party " + c.Party_Name);
    }
    public static void Timer(List<Candidate> candidates)
    {
        LocalTime time2=LocalTime.parse("18:00");
        LocalTime ldt = java.time.LocalTime.now().withSecond(0).withNano(0);
        
         
        if(time2.compareTo(ldt)==0)
        {
           Notification notif1=new SMS();
           Notification notif2=new Email();
           notif1.ShowNotification();
           Winner(candidates);
        }
        
            return;
    }
    public static void main(String[] args) 
    {
        List<Candidate> candidates= new ArrayList<Candidate>();
        List<Voter> voters=new ArrayList<Voter>();
        
        Candidate c1=new Candidate("Ali","l1234",23,"N-League");
        Candidate c2=new Candidate("Ayesha","l1234",24,"Q-League");
        Candidate c3=new Candidate("Asif","l12837",40,"PTI");
        //**********************************************************************************
        candidates.add(c1);
        candidates.add(c2);
        candidates.add(c3);
        //**********************************************************************************
        Voter v1=new Voter("Aleena","l282u54",20);
        Voter v2=new Voter("Muhammad","l13324",18);
        Voter v3=new Voter("Mahad","72731d",19);
        Voter v4=new Voter("Hashim","447fe",23);
        //**********************************************************************************
        voters.add(v1);
        voters.add(v3);
        voters.add(v2);
        voters.add(v4);
        //**********************************************************************************
        v1.Add_Vote(true,c1);
        v2.Add_Vote(true, c3);
        v3.Add_Vote(true, c1);
        v4.Add_Vote(true, c1); 
        //**********************************************************************************
        Timer(candidates);
       
    }

        
}
