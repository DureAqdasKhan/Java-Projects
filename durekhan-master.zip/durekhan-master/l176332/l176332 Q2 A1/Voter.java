/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Dure Khan
 */
public class Voter extends Person {
  boolean vote_done;
  Candidate c1;
    Voter()
    {
        vote_done=false;
    }
    Voter(String n,String c,int a)
    {
        super(n,c,a);
        vote_done=false;
    }
    void Add_Vote(boolean incoming_vote,Candidate c)
    {
        c1=c;
        if(vote_done==false)
        {
          c.Add_Vote1(incoming_vote);
          vote_done=true;
        }
    }
}
