/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author Dure Khan
 
 */
class Candidate extends Person
{
    String Party_Name;
    int vote_count;
    boolean vote;
    Candidate()
    {
        Party_Name=null;
        vote=false;
        vote_count=0;
    }
    Candidate(String n,String c,int a,String p)
    {
        super(n,c,a);
        vote=false;
        Party_Name=p;
        vote_count=0;
    }
    protected void Add_Vote1(boolean incoming_vote)
    {
        vote=incoming_vote;
        vote_count++;
    }
}
