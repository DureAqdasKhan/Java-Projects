/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Dure Khan
 */
abstract class Person
{
    String name;
    String cnic;
    int age;
    public Person()
    {
        name=null;
        cnic=null;
        age=0;
    }
    Person(String n,String c,int a)
    {
        name=n;
        cnic=c;
        age=a;
    }
    
}
